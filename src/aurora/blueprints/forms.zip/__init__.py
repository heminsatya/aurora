try:
    ...
    #do-not-change-me
except:
    pass