# Dependencies
from aurora import Controller, View

# The controller class
class ControllerName(Controller):

	...
