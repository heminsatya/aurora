# Dependencies
from aurora.CLI import CLI


# The main function
def main():
    # Instantiate the CLI class
    cli = CLI()


# Run the main function
if __name__ == '__main__':
    main()
