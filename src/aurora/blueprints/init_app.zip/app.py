# Dependencies
from aurora import Aurora


# Instantiate the root app
root = Aurora()


# Run the root app
if __name__ == '__main__':
    root.run()
