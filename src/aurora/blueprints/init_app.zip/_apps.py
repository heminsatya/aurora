# Dependencies
from aurora.helpers import app

# Apps routes
apps = [
    app(name='errors', url='errors'),
    app(name='aurora', url='aurora'),
]#do-not-change-me
