##
# @Warning! Please do not change this file. This is controlled by the application.
# @Desc: Installed apps (Auto Global)
# @Ex: 'app_name': 'base_url',
# 
apps = {
    'errors': 'errors',     # Error pages
    'aurora': 'aurora',     # Test application
}#do-not-change-me
