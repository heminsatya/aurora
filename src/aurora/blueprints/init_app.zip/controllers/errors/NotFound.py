# Dependencies
from aurora import Controller, Error

# The controller class
class NotFound(Controller):

	# HTTP 404
    def err(self):
        return Error(404, '404.html')

	# HTTP GET Method
    def get(self):
        return Error(404, '404.html')
