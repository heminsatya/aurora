# Dependencies
from aurora import Controller, Error

# The controller class
class MethodForbidden(Controller):

	# HTTP 405
    def err(self):
        return Error(405, '405.html')

	# HTTP GET Method
    def get(self):
        return Error(405, '405.html')
