# Dependencies
from aurora import Controller, Error

# The controller class
class AccessDenied(Controller):

	# HTTP 403
    def err(self):
        return Error(403, '403.html')

	# HTTP GET Method
    def get(self):
        return Error(403, '403.html')
