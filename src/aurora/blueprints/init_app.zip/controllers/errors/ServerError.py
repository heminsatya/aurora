# Dependencies
from aurora import Controller, Error

# The controller class
class ServerError(Controller):

	# HTTP 500
    def err(self):
        return Error(500, '500.html')

	# HTTP GET Method
    def get(self):
        return Error(500, '500.html')
