# Dependencies
from aurora import Controller, Error

# The controller class
class BadRequest(Controller):

	# HTTP 400
    def err(self):
        return Error(400, '400.html')

	# HTTP GET Method
    def get(self):
        return Error(400, '400.html')
