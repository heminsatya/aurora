# Dependencies
from aurora.helpers import router

# Controllers routes
controllers = [
    router(controller='Index'),
]#do-not-change-me
