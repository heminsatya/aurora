# Dependencies
from aurora.helpers import controller

# Controllers routes
controllers = [
    controller(name='Index', url='', methods=['GET']),
]#do-not-change-me
