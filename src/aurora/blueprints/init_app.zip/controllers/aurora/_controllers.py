# Dependencies
from aurora.helpers import controller

# Controllers routes
controllers = [
    controller(name='Index'),
]#do-not-change-me
