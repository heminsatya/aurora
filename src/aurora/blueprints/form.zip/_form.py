# Dependencies
from aurora import Forms
from wtforms import *

# The form class
class FormName(Forms):  
	pass
