# Dependencies
from aurora import Model

# The model class
class ModelName(Model):

    # Model columns
    id = Model.column(datatype='integer')

    # Model meta data
    def __init__(self):
        # Inherit the parent class
        super().__init__()

        # Override the parent class default properties
        self.table = '_table_name'
        self.primary_key = 'id'
